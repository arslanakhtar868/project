from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, db
import hashlib
import os
from flask_session import Session


app = Flask(__name__)
app.secret_key = "your_secret_key"  # Change this to a strong secret key
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
# Firebase Configuration - Load from JSON file
cred = credentials.Certificate(r"D:\important_data\2024-2025 projects\Tech_Hash\PythonProject\PythonProject\training-institute-90eb3-firebase-adminsdk-fbsvc-85a1cfd9af.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://training-institute-90eb3-default-rtdb.firebaseio.com/'
})


UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


# Fetch User Data from Firebase
@app.route('/get-user-data', methods=['POST'])
def get_user_data():
    try:
        data = request.json
        name = data.get("name")

        users_ref = db.reference('users').get()
        if not users_ref:
            return jsonify({"status": "error", "message": "User not found!"}), 404

        for key, user in users_ref.items():
            if user.get("name") == name:
                return jsonify({"status": "success", "data": user}), 200

        return jsonify({"status": "error", "message": "User not found!"}), 404

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500




# Home Page Route
@app.route("/")
def home():
    return render_template("index_page.html")

# Signup Page Route
@app.route('/signup')
def signup_page():
    return render_template("signup.html")

# Signup Form Handling
# Signup Route
@app.route('/signup', methods=['POST'])
def signup():
    try:
        data = request.json
        name = data.get("name")
        email = data.get("email")
        course = data.get("course")
        address = data.get("address")
        password = data.get("password")

        if not name or not email or not course or not address or not password:
            return jsonify({"status": "error", "message": "All fields are required!"}), 400

        # Encrypt password using SHA-256
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Save data to Firebase Realtime Database
        user_ref = db.reference('users').push()
        user_ref.set({
            "name": name,
            "email": email,
            "course": course,
            "address": address,
            "password": hashed_password  # Store encrypted password
        })

        return jsonify({"status": "success", "message": "Signup successful!"}), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# Render Login Page
@app.route('/login')
def login_page():
    return render_template("login.html")

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.json
        name = data.get("name")
        password = data.get("password")

        if not name or not password:
            return jsonify({"status": "error", "message": "Both name and password are required!"}), 400

        # Hash the input password
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Fetch user data from Firebase
        users_ref = db.reference('users').get()

        if not users_ref:
            return jsonify({"status": "error", "message": "No users found!"}), 400

        for user_id, user in users_ref.items():  # user_id is the Firebase Push ID
            if user.get("name") == name and user.get("password") == hashed_password:
                session["user_id"] = user_id  # Store Firebase Push ID in session
                session["name"] = user.get("name")
                session["email"] = user.get("email", "Unknown")

                return jsonify({"status": "success", "message": "Login successful!"}), 200

        return jsonify({"status": "error", "message": "Invalid credentials!"}), 401

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
@app.route('/session-check')
def session_check():
    if "user_id" in session:
        return jsonify({
            "status": "success",
            "message": "User is logged in",
            "user_id": session["user_id"]
        })
    return jsonify({"status": "error", "message": "No user logged in"}), 403

# Dashboard Route (Fetch User Data from Session)
@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        return render_template("dashboard.html", user=session['user'])
    else:
        return redirect(url_for('home'))
# ---------------------- APPLY FOR SUBJECT ----------------------
@app.route('/apply-subject', methods=['POST'])
def apply_subject():
    try:
        if "user_id" not in session:  # Ensure user is logged in
            return jsonify({"status": "error", "message": "Unauthorized! Please log in."}), 403

        data = request.json
        subject = data.get("subject")

        if not subject:
            return jsonify({"status": "error", "message": "Subject is required!"}), 400

        user_id = session["user_id"]  # Get the session user ID (Firebase Push ID)

        applications_ref = db.reference('applications').push()
        applications_ref.set({
            "parent_id": user_id,  # Store the correct parent ID
            "subject": subject,
            "status": "Pending"
        })

        return jsonify({"status": "success", "message": "Subject application submitted!"}), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# ---------------------- FEE SUBMISSION ----------------------
@app.route('/submit-fee', methods=['POST'])
def submit_fee():
    try:
        if "user_id" not in session:  # Ensure user is logged in
            return jsonify({"status": "error", "message": "Unauthorized! Please log in."}), 403

        if 'fee_receipt' not in request.files:
            return jsonify({"status": "error", "message": "No file uploaded!"}), 400

        file = request.files['fee_receipt']

        if file.filename == '':
            return jsonify({"status": "error", "message": "No selected file!"}), 400

        # Save the file securely
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        user_id = session["user_id"]  # Get the session user ID (Firebase Push ID)

        fee_ref = db.reference('fees').push()
        fee_ref.set({
            "parent_id": user_id,  # Store the correct parent ID
            "receipt": file_path,
            "status": "Pending"
        })

        return jsonify({"status": "success", "message": "Fee receipt submitted!"}), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# Logout Route (Clears Session)
@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))

# ---------------------- ADMIN LOGIN ----------------------
@app.route('/admin_login')
def admin_login():
    return render_template("admin_login.html")

@app.route('/admin_auth', methods=['POST'])
def admin_auth():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    if username == "admin_user" and password == "123456789":
        session["admin_logged_in"] = True
        return jsonify({"status": "success", "message": "Admin logged in!", "redirect": "/admin_dashboard"}), 200
    else:
        return jsonify({"status": "error", "message": "Invalid credentials!"}), 401

@app.route('/admin_dashboard')
def admin_dashboard():
    if "admin_logged_in" not in session:
        return redirect(url_for('admin_login'))
    return render_template("admin_dashboard.html")

@app.route('/admin_logout')
def admin_logout():
    session.pop("admin_logged_in", None)
    return redirect(url_for('admin_login'))


# ---------------------- FETCH APPLICATIONS ----------------------
@app.route('/get-applications')
def get_applications():
    if "admin_logged_in" not in session:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    apps_ref = db.reference('applications').get()  # Get all applications
    users_ref = db.reference('users').get()  # Get all users

    print(f"Applications Data: {apps_ref}")
    print(f"Users Data: {users_ref}")

    applications = []
    if apps_ref and users_ref:
        for app_id, app in apps_ref.items():
            parent_id = app.get("parent_id")
            print(f"Checking Application ID: {app_id} with Parent ID: {parent_id}")

            # Match `parent_id` with Firebase Push IDs in `users`
            user_data = users_ref.get(parent_id) if parent_id in users_ref else None

            if user_data:
                applications.append({
                    "id": app_id,
                    "name": user_data.get("name", "Unknown"),
                    "email": user_data.get("email", "Unknown"),
                    "course": user_data.get("course", "Unknown"),
                    "address": user_data.get("address", "Unknown"),
                    "subject": app.get("subject", "Unknown"),
                    "status": app.get("status", "Pending")
                })
            else:
                print(f"❌ No matching user found for Parent ID: {parent_id}")

    return jsonify(applications)


# ---------------------- FETCH FEES ----------------------
@app.route('/get-fees')
def get_fees():
    if "admin_logged_in" not in session:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    fees_ref = db.reference('fees').get()  # Get all fees
    users_ref = db.reference('users').get()  # Get all users

    print(f"Fees Data: {fees_ref}")
    print(f"Users Data: {users_ref}")

    fees = []
    if fees_ref and users_ref:
        for fee_id, fee in fees_ref.items():
            parent_id = fee.get("parent_id")
            print(f"Checking Fee ID: {fee_id} with Parent ID: {parent_id}")

            # Match `parent_id` with Firebase Push IDs in `users`
            user_data = users_ref.get(parent_id) if parent_id in users_ref else None

            if user_data:
                fees.append({
                    "id": fee_id,
                    "name": user_data.get("name", "Unknown"),
                    "email": user_data.get("email", "Unknown"),
                    "course": user_data.get("course", "Unknown"),
                    "address": user_data.get("address", "Unknown"),
                    "status": fee.get("status", "Pending"),
                    "receipt": fee.get("receipt", "#")  # Link to uploaded receipt
                })
            else:
                print(f"❌ No matching user found for Parent ID: {parent_id}")

    return jsonify(fees)
# ---------------------- UPDATE APPLICATION & FEE STATUS ----------------------
@app.route('/update-status', methods=['POST'])
def update_status():
    if "admin_logged_in" not in session:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    data = request.json
    record_id = data.get("id")
    status = data.get("status")
    category = data.get("category")  # 'applications' or 'fees'

    if not record_id or not status or not category:
        return jsonify({"status": "error", "message": "Invalid data"}), 400

    try:
        ref = db.reference(f'{category}/{record_id}')
        ref.update({"status": status})
        return jsonify({"status": "success", "message": f"{category[:-1].capitalize()} status updated to {status}"}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/course')
def admin_page():
    return render_template('courses.html')


@app.route('/add_course', methods=['POST'])
def add_course():
    course_data = {
        "course_id": request.form['course_id'],
        "course_name": request.form['course_name'],
        "duration": request.form['duration'],
        "fee": request.form['fee'],
        "tenure": request.form['tenure'],
        "location": request.form['location'],
        "timing": request.form['timing'],
        "class_type": request.form['class_type']
    }

    ref = db.reference("courses")
    ref.child(course_data["course_name"]).set(course_data)

    return jsonify({"message": "Course Added Successfully!"})


# Predefined questions and answers for the chatbot
chatbot_responses = {
    "hello": "Hi there! How can I help you?",
    "hi": "Hello! Ask me anything about our courses.",
    "what courses do you offer?": "We offer courses in Python, Django, Flutter, React, Front-End, Back-End, and AI.",
    "python course details": "Our Python course covers basics to advanced concepts including data science and automation.",
    "django course details": "Django is a powerful web framework for Python. Our course includes database integration and APIs.",
    "flutter course details": "Flutter is a UI toolkit for building beautiful apps for mobile and web from a single codebase.",
    "react course details": "React is a JavaScript library for building interactive UIs. We cover components, hooks, and API integration.",
    "front-end development course": "Our Front-End course covers HTML, CSS, JavaScript, and frameworks like Bootstrap & React.",
    "back-end development course": "Our Back-End course includes Python, Django, Node.js, and database management.",
    "ai course details": "Our AI course covers machine learning, deep learning, and AI model development.",
    "how can I enroll?": "You can enroll by visiting our website or contacting our support team.",
    "what is the course duration?": "Most courses last between 3 to 6 months depending on the level.",
    "do you provide certificates?": "Yes, we provide completion certificates for all our courses.",
    "is there any fee for the courses?": "Yes, each course has a different fee structure. Please visit our website for more details.",
    "what is the mode of classes?": "We provide both online and in-person classes.",
    "do you offer weekend batches?": "Yes, we have weekend batches available for working professionals.",
    "what is the eligibility for courses?": "Anyone interested in programming can join. No prior experience is required for beginner courses.",
    "what is python?": "Python is a popular programming language used for web development, automation, data science, and AI.",
    "what is django?": "Django is a high-level Python web framework that helps in building secure and maintainable websites.",
    "what is flutter?": "Flutter is Google's UI toolkit for building natively compiled applications for mobile, web, and desktop.",
    "what is react?": "React is a JavaScript library for building fast and interactive user interfaces.",
    "what is AI?": "Artificial Intelligence (AI) enables machines to learn and make decisions similar to humans.",
    "who is the instructor?": "Our instructors are industry professionals with years of experience in their respective fields.",
    "how do I get course materials?": "Course materials will be provided digitally after enrollment.",
    "what are the job opportunities after completing the course?": "You can apply for roles like software developer, AI engineer, web developer, and more.",
    "do you offer internships?": "Yes, we provide internship opportunities for top-performing students.",
    "how can I contact support?": "You can contact us via email or call our support number.",
    "thank you": "You're welcome! Let me know if you have more questions.",
}


@app.route("/bot")
def bot():
    return render_template("chatbot.html")


@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()

    # Fetch all courses from Firebase
    courses_ref = db.reference("courses").get()

    if user_message in ["list courses", " courses",  "what courses do you offer?"]:
        courses_list = ", ".join(courses_ref.keys()) if courses_ref else "No courses available."
        response = f"We offer the following courses: {courses_list}"

        # User asks for a list of all courses
    if user_message in ["name  courses", "available courses", "show courses", "what courses do you offer?"]:
        course_names = ", ".join(courses_ref.keys())  # Get all course names
        response = f"We offer the following courses: {course_names}\n\nType a course name to see more details."


    elif user_message.title() in courses_ref:  # Check if user input matches a course name
        course = courses_ref[user_message.title()]
        response = (f"Course: {user_message.title()}\n"
                    f"Description: {course['description']}\n"
                    f"Duration: {course['duration']}\n"
                    f"Fee: {course['fee']}\n"
                    f"Instructor: {course['instructor']}")
    else:
        response = "I'm sorry, I don't understand that question. Please ask about our courses."

    return jsonify({"response": response})

@app.route('/get_courses', methods=['GET'])
def get_courses():
    courses_ref = db.reference('courses').get()

    if not courses_ref:
        return jsonify({"status": "error", "message": "No courses found!"}), 404

    courses_list = []
    for course_id, course_data in courses_ref.items():
        courses_list.append({
            "course_id": course_data.get("course_id"),
            "course_name": course_data.get("course_name"),
            "course_duration": course_data.get("course_duration", "N/A"),
            "address": course_data.get("location", "N/A"),
            "class_type": course_data.get("class_type", "Unknown"),
            "duration": course_data.get("duration", "Unknown"),
            "fee": course_data.get("fee", "Unknown")
        })

    return jsonify({"status": "success", "courses": courses_list}), 200
@app.route('/get')
def get():
    return render_template('get.html')

if __name__ == "__main__":
    app.run(debug=True)
