from flask import Flask, render_template, request, jsonify
import firebase_admin
from firebase_admin import credentials, db

app = Flask(__name__)

# Firebase Configuration
cred = credentials.Certificate(r"C:\Users\sadeed\PycharmProjects\PythonProject\training-institute-firebase.json")  # Add your Firebase credentials JSON file
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://training-institute-90eb3-default-rtdb.firebaseio.com'  # Replace with your Firebase database URL
})



@app.route('/')
def admin_page():
    return render_template('courses.html')


@app.route('/add_course', methods=['POST'])
def add_course():
    course_data = {
        "course_id": request.form['course_id'],
        "course_name": request.form['course_name'],
        "duration": request.form['duration'],
        "fee": request.form['fee'],
        "tenure": request.form['tenure'],
        "location": request.form['location'],
        "timing": request.form['timing'],
        "class_type": request.form['class_type']
    }

    ref = db.reference("courses")
    ref.child(course_data["course_name"]).set(course_data)

    return jsonify({"message": "Course Added Successfully!"})


# Predefined questions and answers for the chatbot
chatbot_responses = {
    "hello": "Hi there! How can I help you?",
    "hi": "Hello! Ask me anything about our courses.",
    "what courses do you offer?": "We offer courses in Python, Django, Flutter, React, Front-End, Back-End, and AI.",
    "python course details": "Our Python course covers basics to advanced concepts including data science and automation.",
    "django course details": "Django is a powerful web framework for Python. Our course includes database integration and APIs.",
    "flutter course details": "Flutter is a UI toolkit for building beautiful apps for mobile and web from a single codebase.",
    "react course details": "React is a JavaScript library for building interactive UIs. We cover components, hooks, and API integration.",
    "front-end development course": "Our Front-End course covers HTML, CSS, JavaScript, and frameworks like Bootstrap & React.",
    "back-end development course": "Our Back-End course includes Python, Django, Node.js, and database management.",
    "ai course details": "Our AI course covers machine learning, deep learning, and AI model development.",
    "how can I enroll?": "You can enroll by visiting our website or contacting our support team.",
    "what is the course duration?": "Most courses last between 3 to 6 months depending on the level.",
    "do you provide certificates?": "Yes, we provide completion certificates for all our courses.",
    "is there any fee for the courses?": "Yes, each course has a different fee structure. Please visit our website for more details.",
    "what is the mode of classes?": "We provide both online and in-person classes.",
    "do you offer weekend batches?": "Yes, we have weekend batches available for working professionals.",
    "what is the eligibility for courses?": "Anyone interested in programming can join. No prior experience is required for beginner courses.",
    "what is python?": "Python is a popular programming language used for web development, automation, data science, and AI.",
    "what is django?": "Django is a high-level Python web framework that helps in building secure and maintainable websites.",
    "what is flutter?": "Flutter is Google's UI toolkit for building natively compiled applications for mobile, web, and desktop.",
    "what is react?": "React is a JavaScript library for building fast and interactive user interfaces.",
    "what is AI?": "Artificial Intelligence (AI) enables machines to learn and make decisions similar to humans.",
    "who is the instructor?": "Our instructors are industry professionals with years of experience in their respective fields.",
    "how do I get course materials?": "Course materials will be provided digitally after enrollment.",
    "what are the job opportunities after completing the course?": "You can apply for roles like software developer, AI engineer, web developer, and more.",
    "do you offer internships?": "Yes, we provide internship opportunities for top-performing students.",
    "how can I contact support?": "You can contact us via email or call our support number.",
    "thank you": "You're welcome! Let me know if you have more questions.",
}


@app.route("/bot")
def index():
    return render_template("chatbot.html")


@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()

    # Fetch all courses from Firebase
    courses_ref = db.reference("courses").get()

    if user_message in ["list courses", " courses",  "what courses do you offer?"]:
        courses_list = ", ".join(courses_ref.keys()) if courses_ref else "No courses available."
        response = f"We offer the following courses: {courses_list}"

        # User asks for a list of all courses
    if user_message in ["name  courses", "available courses", "show courses", "what courses do you offer?"]:
        course_names = ", ".join(courses_ref.keys())  # Get all course names
        response = f"We offer the following courses: {course_names}\n\nType a course name to see more details."


    elif user_message.title() in courses_ref:  # Check if user input matches a course name
        course = courses_ref[user_message.title()]
        response = (f"Course: {user_message.title()}\n"
                    f"Description: {course['description']}\n"
                    f"Duration: {course['duration']}\n"
                    f"Fee: {course['fee']}\n"
                    f"Instructor: {course['instructor']}")
    else:
        response = "I'm sorry, I don't understand that question. Please ask about our courses."

    return jsonify({"response": response})


if __name__ == '__main__':
    app.run(debug=True)
